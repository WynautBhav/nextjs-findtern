/**
 * Seed the dev database with demo accounts and enough activity that every
 * screen has something real to render.
 *
 * Passwords are hashed with the same argon2id path the login routes use, so a
 * seeded account is indistinguishable from one created through signup. That
 * matters: if this wrote plaintext or a different hash format, the demo would
 * exercise a code path no real user takes.
 *
 * Dev only. Every account here is a well-known password, so `db:seed` refuses
 * to run unless NODE_ENV is not production.
 */
import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";

import * as schema from "../src/lib/db/schema.ts";
import { hashPassword } from "../src/lib/security/password.ts";
import { PRICING_PLANS, PRICING_PLANS_USD } from "../src/lib/content/home.ts";

const PASSWORD = "Findtern@2026";

interface Account {
  role: "admin" | "employer" | "intern";
  email: string;
  name: string;
}

const ACCOUNTS: Account[] = [
  { role: "admin", email: "admin@findtern.dev", name: "Priya Raghavan" },
  { role: "employer", email: "hiring@northwind.dev", name: "Arjun Mehta" },
  { role: "intern", email: "candidate@findtern.dev", name: "Sana Kapoor" },
  { role: "intern", email: "rohan@findtern.dev", name: "Rohan Iyer" },
  { role: "intern", email: "meera@findtern.dev", name: "Meera Nair" },
];

/**
 * Additional employer and intern accounts.
 *
 * These exist so the admin lists, the candidate browser and the employer
 * project lists have enough rows to be worth looking at. Three interns and
 * one company make every table feel broken — a real screen is a scroll, not
 * a single lonely row.
 */
const EXTRA_EMPLOYERS = [
  { companyName: "Lumen Analytics", email: "talent@lumen.dev", city: "Mumbai", state: "Maharashtra" },
  { companyName: "Kettle & Co", email: "people@kettleco.dev", city: "Hyderabad", state: "Telangana" },
  { companyName: "Tidal Health", email: "careers@tidalhealth.dev", city: "Bengaluru", state: "Karnataka" },
];

const EXTRA_INTERNS = [
  { firstName: "Aditi", lastName: "Rao", email: "aditi@findtern.dev", city: "Bengaluru", state: "Karnataka", degree: "BSc IT", college: "Jain University", score: 8.9, skills: ["React", "GraphQL", "Testing"] },
  { firstName: "Kabir", lastName: "Singh", email: "kabir@findtern.dev", city: "Delhi", state: "Delhi", degree: "B.Tech CS", college: "DTU", score: 7.4, skills: ["Python", "Django", "PostgreSQL"] },
  { firstName: "Ishita", lastName: "Verma", email: "ishita@findtern.dev", city: "Pune", state: "Maharashtra", degree: "B.Tech IT", college: "COEP", score: 8.2, skills: ["Figma", "React", "Accessibility"] },
  { firstName: "Vihaan", lastName: "Joshi", email: "vihaan@findtern.dev", city: "Ahmedabad", state: "Gujarat", degree: "BCA", college: "Gujarat University", score: 6.1, skills: ["JavaScript", "HTML", "CSS"] },
  { firstName: "Ananya", lastName: "Menon", email: "ananya@findtern.dev", city: "Kochi", state: "Kerala", degree: "BSc CS", college: "CUSAT", score: 7.9, skills: ["Node.js", "Redis", "Docker"] },
  { firstName: "Devansh", lastName: "Patel", email: "devansh@findtern.dev", city: "Surat", state: "Gujarat", degree: "B.Tech EC", college: "SVNIT", score: 6.8, skills: ["C++", "Embedded", "IoT"] },
];

async function main() {
  if (process.env.NODE_ENV === "production") {
    throw new Error("Refusing to seed demo accounts in production");
  }

  const url = process.env.DATABASE_URL;
  if (!url) throw new Error("DATABASE_URL is not set — run via `npm run db:seed`");

  const client = new pg.Client({ connectionString: url });
  await client.connect();
  const db = drizzle(client, { schema });

  // One hash for all demo accounts. Argon2 salts internally so the stored value
  // is still a real argon2id digest, and `verifyPassword` treats it exactly as
  // it would any user created through signup.
  const pw = await hashPassword(PASSWORD);

  // ── Admin ────────────────────────────────────────────────────────────
  await db.insert(schema.admins).values({
    email: ACCOUNTS[0].email,
    password: pw,
    name: ACCOUNTS[0].name,
    role: "super_admin",
  });

  const roleKeys = [
    ["super_admin", "Super Admin", ["*"]],
    ["admin", "Administrator", ["interns:read", "companies:read", "reports:read"]],
    ["exec_operations", "Operations", ["interns:read", "interns:write", "companies:read"]],
    ["exec_accounts", "Accounts", ["transactions:read", "reports:read"]],
    ["exec_sales", "Sales", ["companies:read", "cms:read"]],
  ] as const;

  await db.insert(schema.adminRoles).values(
    roleKeys.map(([key, name, permissions]) => ({ key, name, permissions: [...permissions] })),
  );

  // ── Employer ─────────────────────────────────────────────────────────
  const [employer] = await db
    .insert(schema.employers)
    .values({
      name: ACCOUNTS[1].name,
      companyName: "Northwind Labs",
      companyEmail: ACCOUNTS[1].email,
      emailVerified: true,
      countryCode: "+91",
      phoneNumber: "9876543210",
      password: pw,
      agreedToTerms: true,
      companySize: "11-50",
      country: "India",
      city: "Bengaluru",
      state: "Karnataka",
      primaryContactName: ACCOUNTS[1].name,
      primaryContactRole: "Head of Engineering",
      websiteUrl: "https://northwind.example",
    })
    .returning();

// ── Extra employers ─────────────────────────────────────────────────
  await db.insert(schema.employers).values(
    EXTRA_EMPLOYERS.map((e, i) => ({
      name: e.companyName,
      companyName: e.companyName,
      companyEmail: e.email,
      emailVerified: true,
      countryCode: "+91",
      phoneNumber: `9866${i}1000${i}`,
      password: pw,
      agreedToTerms: true,
      companySize: "11-50",
      country: "India",
      city: e.city,
      state: e.state,
    })),
  );

  // ── Interns ──────────────────────────────────────────────────────────
  const internRows = ACCOUNTS.slice(2).map((a, i) => ({
    firstName: a.name.split(" ")[0],
    lastName: a.name.split(" ").slice(1).join(" "),
    email: a.email,
    emailVerified: true,
    isActive: true,
    countryCode: "+91",
    phoneNumber: `9876${i}5001${i}`,
    password: pw,
    agreedToTerms: true,
    role: "intern",
  }));
  const interns = await db.insert(schema.users).values(internRows).returning();

  // ── Extra interns ────────────────────────────────────────────────────
  const extraInterns = await db
    .insert(schema.users)
    .values(
      EXTRA_INTERNS.map((p, i) => ({
        firstName: p.firstName,
        lastName: p.lastName,
        email: p.email,
        emailVerified: true,
        isActive: true,
        countryCode: "+91",
        // The (country_code, phone_number) pair is uniquely indexed, so these
        // must not collide with the primary interns above.
        phoneNumber: `9888${i}1000${i}`,
        password: pw,
        agreedToTerms: true,
        role: "intern",
      })),
    )
    .returning();

  // ── Projects ─────────────────────────────────────────────────────────
  const projectRows = [
    {
      employerId: employer.id,
      projectName: "React Dashboard Rebuild",
      skills: ["React", "TypeScript", "Tailwind CSS"],
      scopeOfWork: "Rebuild the analytics dashboard component library.",
      locationType: "remote",
      status: "active",
      fullTimeOffer: true,
      city: "Bengaluru",
      state: "Karnataka",
      timezone: "Asia/Kolkata",
    },
    {
      employerId: employer.id,
      projectName: "Payments API Integration",
      skills: ["Node.js", "PostgreSQL", "REST APIs"],
      scopeOfWork: "Integrate Razorpay webhooks and reconcile settlements.",
      locationType: "hybrid",
      status: "active",
      fullTimeOffer: false,
      city: "Bengaluru",
      state: "Karnataka",
      timezone: "Asia/Kolkata",
    },
    {
      employerId: employer.id,
      projectName: "Marketing Site Motion Pass",
      skills: ["GSAP", "CSS", "Figma"],
      scopeOfWork: "Add scroll choreography and polish responsive states.",
      locationType: "remote",
      status: "active",
      fullTimeOffer: false,
      city: "Bengaluru",
      state: "Karnataka",
      timezone: "Asia/Kolkata",
    },
  ];
  const projects = await db.insert(schema.projects).values(projectRows).returning();

  // ── Proposals ────────────────────────────────────────────────────────
  const proposalRows = [
    {
      employerId: employer.id,
      internId: interns[0].id,
      projectId: projects[0].id,
      flowType: "direct",
      status: "accepted",
      currency: "INR",
      offerDetails: {
        role: "Frontend Engineering Intern",
        durationWeeks: 12,
        hoursPerWeek: 20,
        stipendMinor: 400000,
      },
      aiRatings: { communication: 8, coding: 9, problemSolving: 8 },
    },
    {
      employerId: employer.id,
      internId: interns[1].id,
      projectId: projects[1].id,
      flowType: "interview_first",
      status: "sent",
      currency: "INR",
      offerDetails: {
        role: "Backend Engineering Intern",
        durationWeeks: 16,
        hoursPerWeek: 25,
        stipendMinor: 500000,
      },
      aiRatings: { communication: 7, coding: 8, problemSolving: 9 },
    },
    {
      employerId: employer.id,
      internId: interns[2].id,
      projectId: projects[2].id,
      flowType: "direct",
      status: "accepted",
      currency: "INR",
      offerDetails: {
        role: "Design Engineering Intern",
        durationWeeks: 8,
        hoursPerWeek: 15,
        stipendMinor: 300000,
      },
      aiRatings: { communication: 9, coding: 7, problemSolving: 8 },
    },
  ];
  const proposals = await db.insert(schema.proposals).values(proposalRows).returning();

  // ── Onboarding profiles, so the candidate browser has real rows ──────
  // Academics live in `extraData` rather than as columns, so the candidate
  // browser reads college/degree/score from there.
  await db.insert(schema.internOnboarding).values([
    {
      userId: interns[0].id,
      city: "Bengaluru",
      state: "Karnataka",
      pinCode: "560001",
      skills: ["React", "TypeScript", "Tailwind CSS"],
      bio: "Frontend-focused, built two production dashboards.",
      locationTypes: ["remote", "hybrid"],
      hasLaptop: true,
      linkedinUrl: "https://linkedin.com/in/demo-sana",
      previewSummary: "Christ University, BSc CS 2027. Score 8.4.",
      extraData: {
        college: "Christ University",
        degree: "BSc Computer Science",
        graduationYear: 2027,
        findternScore: 8.4,
        openToWork: true,
      },
    },
    {
      userId: interns[1].id,
      city: "Chennai",
      state: "Tamil Nadu",
      pinCode: "600001",
      skills: ["Node.js", "PostgreSQL", "REST APIs"],
      bio: "Backend and data work. Comfortable with schema design.",
      locationTypes: ["hybrid", "onsite"],
      hasLaptop: true,
      previewSummary: "NIT Trichy, B.Tech IT 2026. Score 7.8.",
      extraData: {
        college: "NIT Trichy",
        degree: "B.Tech IT",
        graduationYear: 2026,
        findternScore: 7.8,
        openToWork: true,
      },
    },
    {
      userId: interns[2].id,
      city: "Pune",
      state: "Maharashtra",
      pinCode: "411001",
      skills: ["GSAP", "CSS", "Figma"],
      bio: "Design engineer. I care about motion that means something.",
      locationTypes: ["remote"],
      hasLaptop: false,
      previewSummary: "Symbiosis Institute, BDes 2027. Score 8.1.",
      extraData: {
        college: "Symbiosis Institute",
        degree: "BDes Communication Design",
        graduationYear: 2027,
        findternScore: 8.1,
        openToWork: true,
      },
    },
    // The extra cohort, so the candidate browser has enough rows to sort,
    // filter and paginate.
    ...EXTRA_INTERNS.map((p, i) => ({
      userId: extraInterns[i].id,
      city: p.city,
      state: p.state,
      pinCode: `${110000 + i * 137}`,
      skills: p.skills,
      bio: `${p.degree} at ${p.college}. Wants work I can point at afterwards.`,
      locationTypes: i % 2 === 0 ? ["remote", "hybrid"] : ["onsite", "hybrid"],
      hasLaptop: i !== 3,
      previewSummary: `${p.college}, ${p.degree}. Score ${p.score}.`,
      extraData: {
        college: p.college,
        degree: p.degree,
        graduationYear: 2026 + (i % 2),
        findternScore: p.score,
        openToWork: p.score > 6.5,
      },
    })),
  ]);

  // ── Interviews ───────────────────────────────────────────────────────
  const in5days = new Date(Date.now() + 5 * 86_400_000);
  const in2days = new Date(Date.now() + 2 * 86_400_000);

  await db.insert(schema.interviews).values([
    {
      employerId: employer.id,
      internId: interns[0].id,
      projectId: projects[0].id,
      status: "scheduled",
      slot1: in5days,
      slot2: new Date(in5days.getTime() + 86_400_000),
      timezone: "Asia/Kolkata",
      meetingLink: "https://meet.google.com/dev-demo-000",
    },
    {
      employerId: employer.id,
      internId: interns[1].id,
      projectId: projects[1].id,
      status: "pending",
      slot1: in2days,
      timezone: "Asia/Kolkata",
    },
  ]);

  // ── Timesheets ───────────────────────────────────────────────────────
  const now = new Date();
  await db.insert(schema.timesheets).values([
    {
      proposalId: proposals[0].id,
      employerId: employer.id,
      internId: interns[0].id,
      periodStart: new Date(now.getFullYear(), now.getMonth() - 1, 1),
      periodEnd: new Date(now.getFullYear(), now.getMonth(), 0),
      status: "approved",
      entries: [
        { date: "2026-09-07", hours: 6, note: "Dashboard component library" },
        { date: "2026-09-09", hours: 5, note: "Table primitives + states" },
      ],
      submittedAt: new Date(now.getFullYear(), now.getMonth(), 1),
      approvedAt: new Date(now.getFullYear(), now.getMonth(), 3),
    },
    {
      proposalId: proposals[2].id,
      employerId: employer.id,
      internId: interns[2].id,
      periodStart: new Date(now.getFullYear(), now.getMonth() - 1, 1),
      periodEnd: new Date(now.getFullYear(), now.getMonth(), 0),
      status: "submitted",
      entries: [{ date: "2026-09-11", hours: 4, note: "Scroll choreography pass" }],
      submittedAt: new Date(now.getFullYear(), now.getMonth(), 2),
    },
  ]);

  // ── Payments ─────────────────────────────────────────────────────────
  await db.insert(schema.employerPayments).values([
    {
      employerId: employer.id,
      orderId: "order_demo_001",
      paymentId: "pay_demo_001",
      amountMinor: 900000,
      currency: "INR",
      status: "captured",
      paidAt: new Date(now.getFullYear(), now.getMonth(), 5),
    },
  ]);

  await db.insert(schema.internPayouts).values([
    {
      internId: interns[0].id,
      amountMinor: 200000,
      currency: "INR",
      status: "paid",
      method: "bank",
      paidAt: new Date(now.getFullYear(), now.getMonth(), 6),
    },
    {
      internId: interns[2].id,
      amountMinor: 150000,
      currency: "INR",
      status: "pending",
      method: "bank",
    },
  ]);

  // ── Notifications ────────────────────────────────────────────────────
  await db.insert(schema.notifications).values([
    {
      recipientType: "intern",
      recipientId: interns[0].id,
      type: "proposal_accepted",
      title: "Proposal accepted",
      message: "Northwind Labs accepted your proposal for React Dashboard Rebuild.",
    },
    {
      recipientType: "intern",
      recipientId: interns[0].id,
      type: "interview_scheduled",
      title: "Interview scheduled",
      message: "Your interview with Northwind Labs is confirmed for next week.",
    },
    {
      recipientType: "employer",
      recipientId: employer.id,
      type: "timesheet_submitted",
      title: "Timesheet awaiting review",
      message: "Meera Nair submitted a timesheet for Design Engineering Intern.",
    },
    {
      recipientType: "employer",
      recipientId: employer.id,
      type: "new_candidate",
      title: "New candidate match",
      message: "Rohan Iyer scored 7.8 and matches your Node.js requirement.",
    },
  ]);

  // ── Pricing plans ─────────────────────────────────────────────────────
  // Seeded from the same table the marketing site renders, so the numbers the
  // public sees are the numbers an admin can then edit. Until this existed,
  // pricing_plans was empty and every amount on /pricing came from a
  // hardcoded fallback that no admin could change.
  await db.insert(schema.pricingPlans).values([
    ...PRICING_PLANS.map((p) => ({
      slug: p.slug,
      displayName: p.displayName,
      region: "IN",
      currency: p.currency,
      priceHourlyMinor: p.priceHourlyMinor,
      perHireChargeMinor: p.perHireChargeMinor,
      internshipDuration: p.internshipDuration,
      features: p.features,
      gstApplicable: p.gstApplicable,
      sortOrder: p.sortOrder,
      isActive: true,
    })),
    ...PRICING_PLANS_USD.map((p) => ({
      slug: p.slug,
      displayName: p.displayName,
      region: null,
      currency: p.currency,
      priceHourlyMinor: p.priceHourlyMinor,
      perHireChargeMinor: p.perHireChargeMinor,
      internshipDuration: p.internshipDuration,
      features: p.features,
      gstApplicable: p.gstApplicable,
      sortOrder: p.sortOrder,
      isActive: true,
    })),
  ]);

  // ── Promo code ───────────────────────────────────────────────────────
  await db.insert(schema.promoCodes).values({
    code: "LAUNCH25",
    description: "25% off the first hire",
    discountType: "percentage",
    discountValue: 25,
    maxUsages: 100,
    isActive: true,
  });

  // Report what actually landed, so a silent partial seed is visible rather
  // than discovered later as an empty dashboard.
  const [admins, employers, users, projectsCount, proposalsCount, interviews, timesheets, notifications] =
    await Promise.all([
      db.$count(schema.admins),
      db.$count(schema.employers),
      db.$count(schema.users),
      db.$count(schema.projects),
      db.$count(schema.proposals),
      db.$count(schema.interviews),
      db.$count(schema.timesheets),
      db.$count(schema.notifications),
    ]);

  console.log(
    [
      "",
      "seeded.",
      "",
      `  admins ${admins}  employers ${employers}  interns ${users}`,
      `  projects ${projectsCount}  proposals ${proposalsCount}  interviews ${interviews}`,
      `  timesheets ${timesheets}  notifications ${notifications}`,
      "",
      "  Sign in at http://localhost:3100",
      "",
      `  Admin      ${ACCOUNTS[0].email}  → /admin/login`,
      `  Employer   ${ACCOUNTS[1].email}  → /employer/login`,
      `  Intern     ${ACCOUNTS[2].email}  → /login`,
      "",
      "",
      `  Password (all accounts): ${PASSWORD}`,
      "",
    ].join("\n"),
  );

  await client.end();
}

main().catch((err: unknown) => {
  console.error(err instanceof Error ? err.message : err);
  process.exit(1);
});